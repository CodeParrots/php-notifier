=== PHP Notifier ===
Contributors:      codeparrots, eherman24, brothman01
Tags:              php, version, notifier, notice, deprecated, alert, email
Requires at least: 4.4
Tested up to:      4.7.2
Stable tag:        1.0.0
License:           GPL-2.0
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

PHP Notifier.
